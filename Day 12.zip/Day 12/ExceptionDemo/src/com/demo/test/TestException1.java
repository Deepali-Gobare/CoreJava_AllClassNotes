package com.demo.test;

public class TestException1 {

	public static void main(String[] args) {
		String s=null;
		System.out.println(s);
		System.out.println(s.length());
	}

}
