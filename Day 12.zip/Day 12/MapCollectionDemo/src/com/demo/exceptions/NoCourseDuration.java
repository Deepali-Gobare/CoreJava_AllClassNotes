package com.demo.exceptions;

public class NoCourseDuration extends Exception{
	public NoCourseDuration(String msg) {
		super(msg);
	}

}
