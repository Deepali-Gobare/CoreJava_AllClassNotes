package com.demo.beans;

import com.demo.interfaces.MyFunctionalInterface;

public class MyTestClass implements MyFunctionalInterface {

	@Override
	public void m1() {
		System.out.println("In m1 in MyTestClass");
		
	}

}
