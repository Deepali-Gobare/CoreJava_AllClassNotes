package com.demo.test;

import com.demo.beans.MtTest;

public class TestI1I2 {

	public static void main(String[] args) {
		MtTest ob=new MtTest();
		ob.m1();

	}

}
