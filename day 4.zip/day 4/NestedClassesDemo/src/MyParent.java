
public class MyParent {
	private int id;
	private String name;
	static class MyChild{
		private int id;
		public void m22() {
			System.out.println("in m22");
		}
	}
	public void m21() {
		System.out.println("in m21");
	}

}
